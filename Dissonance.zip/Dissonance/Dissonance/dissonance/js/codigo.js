// Espera o DOM ser totalmente carregado
document.addEventListener("DOMContentLoaded", function() {
    // Seleciona as imagens dos álbuns
    const album1 = document.getElementById("album1");
    const album2 = document.getElementById("album2");
    const album3 = document.getElementById("album3");

    // Seleciona os elementos de texto dos álbuns
    const textAlbum1 = document.getElementById("text-album1");
    const textAlbum2 = document.getElementById("text-album2");
    const textAlbum3 = document.getElementById("text-album3");

    // Função para esconder todos os textos
    function hideAllTexts() {
        textAlbum1.classList.remove('active');
        textAlbum2.classList.remove('active');
        textAlbum3.classList.remove('active');
    }

    // Função para mostrar o texto do álbum selecionado
    function showText(albumNumber) {
        hideAllTexts(); // Esconde todos os textos antes de mostrar o do álbum
        if (albumNumber === 1) {
            textAlbum1.classList.add('active');
        } else if (albumNumber === 2) {
            textAlbum2.classList.add('active');
        } else if (albumNumber === 3) {
            textAlbum3.classList.add('active');
        }
    }

    // Adiciona eventos de clique para cada álbum
    album1.addEventListener("click", function() {
        showText(1);
    });

    album2.addEventListener("click", function() {
        showText(2);
    });

    album3.addEventListener("click", function() {
        showText(3);
    });

    // Exibe o texto do primeiro álbum por padrão
    showText(1);
});

//LOCAL DE FEEDBACK: ENVIO DE COMENTÁRIO NO CONSOLE E HTML
function envio_comentario_js(){
    var comentario_console = document.getElementById("comentario").value;
    var comentario = document.getElementById("comentario").value;

    console.log("Comentario Enviado: " + comentario_console);
    document.getElementById('area_receber').innerHTML = comentario;
}

document.getElementById("DLMODE").addEventListener("click", function () {
    const body = document.body;
    // Troca light e dark mode
    //  Se estiver claro vai para escuro e vice-versa
    if (body.style.backgroundColor === "rgb(24, 24, 24)") {
        body.style.backgroundColor = "whitesmoke"; // Modo claro
        body.style.color = "black";
    } else {
        body.style.backgroundColor = "rgb(24, 24, 24)"; // Modo escuro
        body.style.color = "#161616";
    }
});
